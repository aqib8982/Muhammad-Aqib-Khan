# Muhammad Aqib Khan — Portfolio 2026-2027

Live portfolio site, identical to the PDF version.

## Publish on GitHub Pages
1. Create a new public repo (e.g. `portfolio`).
2. Upload everything in this folder (`index.html`, `assets/`, `.nojekyll`, `README.md`).
3. Go to **Settings → Pages → Source: Deploy from a branch → main / (root) → Save**.
4. Your site will be live at `https://<your-username>.github.io/portfolio/`.

Tip: name the repo `<your-username>.github.io` to get the shorter URL `https://<your-username>.github.io/`.
